# AIG II Remote Agent Bootstrap

Bridge URL:
https://aig-remote-bridge.onrender.com

Status:
- Bridge staging service created.
- Authentication credentials are intentionally NOT included in this package.
- Persistent Postgres instance exists, but DATABASE_URL is not yet linked because the Render connector does not expose database credentials.
- Do not call the route operational until secure pairing and Windows first-run gates pass.

Windows install path:
%ProgramData%\AIG-II\RemoteAgent

Install command after secure pairing:
PowerShell (Administrator):
  .\Install-AigRemoteAgent.ps1 -BridgeUrl "https://aig-remote-bridge.onrender.com" -AgentToken "<SECURE_AGENT_TOKEN>"

Whitelisted commands only:
- NOX_STATUS
- NOX_START
- RESUME_463

RESUME_463 safety:
- repo: E:\AIG\AIG\AIG-II-429-win
- floor commit: 6cd20f36
- refuses rollback/non-descendant HEAD
- invokes only AIG-II-463-RESUME-READONLY.ps1

Nox:
- adb: E:\Program Files\Nox\bin\nox_adb.exe
- target: 127.0.0.1:62026

No arbitrary remote shell is provided.
No CNC machine command is provided.
