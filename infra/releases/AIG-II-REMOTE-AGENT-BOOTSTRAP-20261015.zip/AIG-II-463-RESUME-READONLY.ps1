﻿$ErrorActionPreference = "Continue"

$Repo = "E:\AIG\AIG\AIG-II-429-win"
$NoxAdb = "E:\Program Files\Nox\bin\nox_adb.exe"
$Target = "127.0.0.1:62026"
$Expected462 = "6cd20f36"
$OutDir = Join-Path $Repo "release\463-resume-readonly"
$Log = Join-Path $OutDir "resume-463-readonly.log"

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function W([string]$s) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $s"
    $line | Tee-Object -FilePath $Log -Append
}

W "AIG-II 463 READ-ONLY RESUME CHECK"
W "Repo=$Repo"
W "Target=$Target"

if (-not (Test-Path $Repo)) {
    W "BLOCK: repo missing"
    exit 2
}

Push-Location $Repo
try {
    $head = (git rev-parse HEAD 2>&1).ToString().Trim()
    W "HEAD=$head"

    git cat-file -e "$Expected462^{commit}" 2>$null
    if ($LASTEXITCODE -ne 0) {
        W "BLOCK: expected 462 commit $Expected462 is not present in this repo"
        exit 3
    }

    git merge-base --is-ancestor $Expected462 HEAD
    if ($LASTEXITCODE -ne 0) {
        W "BLOCK: HEAD is not a descendant of 462; refuse downgrade path"
        exit 4
    }
    W "PASS: 462 is ancestor of current HEAD"

    W "GIT STATUS:"
    git status --short 2>&1 | ForEach-Object { W "  $_" }

    $RedTest = Join-Path $Repo "tests\aigii\AuthorityCockpit463Regression.kt"
    $DesktopGradle = Join-Path $Repo "desktop\build.gradle.kts"
    W ("RED TEST exists=" + (Test-Path $RedTest))
    W ("desktop/build.gradle.kts exists=" + (Test-Path $DesktopGradle))

    $p = Get-Process -Id 17908 -ErrorAction SilentlyContinue
    if ($p) {
        W "PID 17908 still exists: $($p.ProcessName)"
    } else {
        W "PID 17908 no longer exists; use the same RED Gate task only, do not redesign"
    }

    $GradleCandidates = @(
        (Join-Path $Repo "gradlew.bat"),
        "E:\AIG\AIG\AIG-II\gradlew.bat"
    )
    $Gradle = $GradleCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

    if ((Test-Path $RedTest) -and $Gradle) {
        W "RUN: same 463 RED Gate via $Gradle"
        & $Gradle -p $Repo :desktop:authorityCockpit463Regression 2>&1 |
            ForEach-Object { W "GRADLE $_" }
        W "RED GATE EXIT=$LASTEXITCODE"
    } else {
        W "SKIP: RED Gate task cannot be replayed safely (test or wrapper missing)"
    }

    if (Test-Path $NoxAdb) {
        W "NOX: connect"
        & $NoxAdb connect $Target 2>&1 | ForEach-Object { W "ADB $_" }

        W "NOX: state"
        & $NoxAdb -s $Target get-state 2>&1 | ForEach-Object { W "ADB $_" }

        W "NOX: model"
        & $NoxAdb -s $Target shell getprop ro.product.model 2>&1 |
            ForEach-Object { W "ADB $_" }

        W "NOX: display"
        & $NoxAdb -s $Target shell wm size 2>&1 |
            ForEach-Object { W "ADB $_" }

        W "AIG package version"
        & $NoxAdb -s $Target shell dumpsys package com.aigii.app 2>&1 |
            Select-String -Pattern "versionCode=|versionName=" |
            ForEach-Object { W "ADB $($_.Line.Trim())" }
    } else {
        W "BLOCK: nox_adb.exe missing"
    }

    W "DONE: read-only resume evidence collected. No product source was modified by this script."
}
finally {
    Pop-Location
}
