package com.aig.core.settings

enum class Language { ZH_TW, ENGLISH }
enum class RendererBackend { AUTO, VULKAN, OPENGL_ES3, D3D11 }
enum class FpsMode(val fps:Int) { FPS30(30), FPS60(60), FPS90(90), FPS120(120), AUTO(0) }
data class RuntimeSettings(
    val language:Language=Language.ZH_TW,
    val renderer:RendererBackend=RendererBackend.AUTO,
    val gpu3d:Boolean=true,
    val fps:FpsMode=FpsMode.FPS60,
    val rgb:Boolean=true,
    val hud:Boolean=false,
    val precisionMm:Double=0.001,
    val offlineFirst:Boolean=true
)
