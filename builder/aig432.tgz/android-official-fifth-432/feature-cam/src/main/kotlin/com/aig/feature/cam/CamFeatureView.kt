package com.aig.feature.cam

import android.content.Context
import android.widget.LinearLayout
import android.widget.TextView
import com.aig.core.cam.*
import com.aig.core.ui.UiKit

object CamFeatureView {
    fun create(context:Context):LinearLayout {
        var state=CamState(path=listOf(
            ManualCamPoint(0.0,0.0,3.0,Motion.G0,10.0,20.0,30.0),
            ManualCamPoint(0.0,0.0,-5.0,Motion.G1,10.0,20.0,30.0),
            ManualCamPoint(30.0,0.0,-5.0,Motion.G1,10.0,20.0,30.0)
        ))
        val root=UiKit.column(context); val title=UiKit.label(context,"CAM • MANUAL FIRST • Safe-Z ${state.safeZ}",17f); val text=TextView(context)
        fun render(){ text.text=state.path.mapIndexed { i,p -> "%02d %s X%.3f Y%.3f Z%.3f A%.3f B%.3f C%.3f".format(i,p.motion,p.x,p.y,p.z,p.axisA,p.axisB,p.axisC) }.joinToString("\n") }
        val row=LinearLayout(context).apply { orientation=LinearLayout.HORIZONTAL }
        UiKit.addButton(row,"MANUAL"){ state=state.copy(source=CamSource.MANUAL); title.text="CAM • MANUAL FIRST • Safe-Z ${state.safeZ}" }
        UiKit.addButton(row,"AUTO"){ state=state.copy(source=CamSource.AUTO); title.text="CAM • AUTO • Safe-Z ${state.safeZ}" }
        UiKit.addButton(row,"避讓壓板"){ state=state.copy(source=CamSource.MANUAL); state=CamWorkflow.insertFixtureBypass(state,1,10.0,10.0,20.0,20.0,-5.0); render() }
        root.addView(title); root.addView(row); text.setTextColor(android.graphics.Color.WHITE); text.textSize=12f; root.addView(text); render(); return root
    }
}
