plugins { id("com.android.library") }
android {
    namespace = "com.aig.feature.cam"
    compileSdk = 36
    defaultConfig { minSdk = 28 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies { implementation(project(":core-ui")); implementation(project(":core-cam")) }
