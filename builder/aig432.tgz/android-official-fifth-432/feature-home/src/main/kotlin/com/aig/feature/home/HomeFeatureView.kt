package com.aig.feature.home

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import com.aig.core.settings.RuntimeSettings
import com.aig.core.ui.UiKit

object HomeFeatureView {
    fun create(context:Context):LinearLayout = UiKit.column(context).apply {
        gravity=Gravity.CENTER_HORIZONTAL
        addView(UiKit.label(context,"AIG-II / AIG CNC",28f))
        addView(UiKit.label(context,"第五架構 • Android 官方 Runtime",17f))
        val s=RuntimeSettings()
        addView(UiKit.label(context,"0.001 mm • ${s.fps.fps}Hz • GPU 3D ${if(s.gpu3d) "ON" else "OFF"} • Offline-first",14f))
        addView(UiKit.label(context,"正式頁面由上方 CAD / CAM / NC 進入；SIM / 3~6AX 必須等 Unity 真 Renderer 匯入才啟用，不做假 3D。",13f).apply { setTextColor(Color.LTGRAY) })
    }
}
