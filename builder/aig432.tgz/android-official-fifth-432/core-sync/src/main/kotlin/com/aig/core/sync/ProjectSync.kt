package com.aig.core.sync

enum class SyncState { CLEAN, LOCAL_DIRTY, REMOTE_NEWER, CONFLICT }
enum class ConflictChoice { ADOPT_REMOTE, KEEP_LOCAL, SAVE_COPY }
data class RevisionMeta(val revision:Long=0,val baseRevision:Long=0,val digest:String="",val platform:String="UNKNOWN")
object ProjectSyncPolicy {
    const val AUTO_APPLY = false
    const val NETWORK_REQUIRED = false
    fun classify(local:RevisionMeta, remote:RevisionMeta, localDirty:Boolean):SyncState {
        if(local.digest.isNotBlank() && local.digest==remote.digest) return SyncState.CLEAN
        if(localDirty && remote.revision>local.baseRevision) return SyncState.CONFLICT
        if(remote.revision>local.revision) return SyncState.REMOTE_NEWER
        if(localDirty || local.revision>remote.revision) return SyncState.LOCAL_DIRTY
        return SyncState.CLEAN
    }
}
