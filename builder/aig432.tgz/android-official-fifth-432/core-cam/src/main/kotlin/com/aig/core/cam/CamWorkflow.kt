package com.aig.core.cam

enum class CamSource { AUTO, MANUAL }
enum class Motion { G0, G1 }
data class ManualCamPoint(
    val x:Double, val y:Double, val z:Double, val motion:Motion,
    val axisA:Double=0.0, val axisB:Double=0.0, val axisC:Double=0.0
)
data class CamState(
    val source:CamSource=CamSource.MANUAL,
    val safeZ:Double=3.0,
    val path:List<ManualCamPoint> = listOf(
        ManualCamPoint(0.0,0.0,3.0,Motion.G0),
        ManualCamPoint(0.0,0.0,-1.0,Motion.G1)
    )
)
object CamWorkflow {
    const val AVOIDANCE_RULE="lift to Safe-Z -> move XY -> landing XY at Safe-Z -> lower"
    fun insertFixtureBypass(state:CamState, afterIndex:Int, safeX:Double, safeY:Double, landingX:Double, landingY:Double, landingZ:Double):CamState {
        require(state.source==CamSource.MANUAL) { "Fixture bypass requires MANUAL" }
        require(afterIndex in state.path.indices)
        val from=state.path[afterIndex]
        val keep={x:Double,y:Double,z:Double,m:Motion -> ManualCamPoint(x,y,z,m,from.axisA,from.axisB,from.axisC)}
        val p=state.path.toMutableList(); val i=afterIndex+1
        p.add(i, keep(from.x,from.y,state.safeZ,Motion.G0))
        p.add(i+1, keep(safeX,safeY,state.safeZ,Motion.G0))
        p.add(i+2, keep(landingX,landingY,state.safeZ,Motion.G0))
        p.add(i+3, keep(landingX,landingY,landingZ,Motion.G1))
        return state.copy(path=p)
    }
}
