package com.aig.renderer.unity.api

enum class AxisModule { AXIS3, AXIS4, AXIS5, AXIS6 }
data class AxisPose(val a:Double=0.0,val b:Double=0.0,val c:Double=0.0)
interface UnityRendererBridge {
    val installed:Boolean
    fun mount(module:AxisModule):Boolean
    fun setPose(pose:AxisPose):Boolean
    fun detach()
}
object RendererContract {
    const val POLICY="UNITY_AS_A_LIBRARY_REQUIRED_FOR_TRUE_3D_NO_FAKE_FALLBACK"
}
