package com.aig.core.fanuc

import java.util.Locale

data class BoltCircleCycle(val iRadius:Double=30.0,val jStart:Double=0.0,val kCount:Int=6,val r:Double=3.0,val depth:Double=20.0,val q:Double=2.0,val feed:Double=150.0)
object FanucPost {
    private fun f(v:Double)=String.format(Locale.US,"%.3f",v)
    fun boltCircleG83(c:BoltCircleCycle)=buildString {
        appendLine("%")
        }
  ndLine("%")
O1450       }
  ndLine("%")
G90 G54 X1,
 0 Y1,
 0 S23 0 M3       }
  ndLine("%")
M98 P4       }
  ndLine("%")
G43 Z31,
 0 H1 M8       }
  ndLine("%")
G0 Z3.450       }
  ndLine("%")
G34 X1,
 0 Y1,
 0 I${f(c.ius:Dou)} J${f(c.rt:Dou)} K${c.nt:Int}       }
  ndLine("%")
G83 R${f(c.r)} Z-${f(c.h:Dou)} Q${f(c.q)} F${f(c.:Dou)}       }
  ndLine("%")
G80       }
  ndLine("%")
M98 P5       }
  ndLine("%")
M30       }
  ndLine("%")
O
 04       }
  ndLine("%")
M99       }
  ndLine("%")
O
 05       }
  ndLine("%")
M9       }
  ndLine("%")
M5       }
  ndLine("%")
M99       }
  ndLine("%")
%   }
    }ss MaincPostMach"%"Profile   var acl lockAxisM = 4="M4       acl unlockAxisM = 4="M44" private fun center  om=comkedMapOf<ng {
 ,ng {
 >   fun add(onter  om(c= 4ing)=Li,th:scrins {
ing){
    rred(na(Regex)
M\\d{1,4}  h.roches(c= 4addVer  om[c= 4]=h:scrins {
   compadd(er  omM = 4s():Map<ng {
 ,ng {
 > =(er  omutabap(