# AIG Fifth Architecture 432 — Android Official Host

Official Android multi-module host for AIG-II / AIG CNC Fifth Architecture.

- Android Studio stable: Rabbit 1 (2026.2.1)
- Android Gradle Plugin: 9.4.0
- Gradle: 9.6
- Built-in Kotlin: enabled (no kotlin-android plugin)
- compileSdk / targetSdk: 36 stable
- minSdk: 28
- Debug APK is automatically debug-signed by Android build tooling.

## Real first-slice features
- RGB black production host and real navigation callbacks
- CAD: real LINE / RECT / CIRCLE / HOLE drawing canvas at 0.001 mm quantization
- CAM: MANUAL-first path and real Safe-Z fixture bypass preserving A/B/C
- NC: editable Fanuc program, G34 + G83, O4/O5, M42/M44 and custom M-code
- Offline-first sync/settings contracts

## No-fake policy
SIM and 3AX/4AX/5AX/6AX do not render placeholder machinery. They remain explicitly unavailable until Unity is exported as an Android Library and connected through renderer-unity-api.
