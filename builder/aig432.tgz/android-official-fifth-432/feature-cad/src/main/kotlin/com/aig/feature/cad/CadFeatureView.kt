package com.aig.feature.cad

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.aig.core.cad.*
import com.aig.core.ui.UiKit
import kotlin.math.hypot

class CadCanvasView(context:Context, private val doc:CadDocument, private val status:TextView):View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.CYAN; strokeWidth=3f; style=Paint.Style.STROKE }
    private val scale=8f
    private var first:PointMm?=null
    init { setBackgroundColor(Color.rgb(2,4,7)) }
    override fun onTouchEvent(e:MotionEvent):Boolean {
        if(e.action!=MotionEvent.ACTION_UP) return true
        val p=PointMm(CadPrecision.q((e.x/scale).toDouble()), CadPrecision.q((e.y/scale).toDouble()))
        val a=first
        if(a==null){ first=p; status.text="${doc.activeTool} 起點 X${"%.3f".format(p.x)} Y${"%.3f".format(p.y)}"; return true }
        when(doc.activeTool){
            CadTool.LINE -> doc.add(CadLine(a,p))
            CadTool.RECT -> doc.add(CadRect(a,p))
            CadTool.CIRCLE, CadTool.HOLE -> doc.add(CadCircle(a,hypot(p.x-a.x,p.y-a.y)))
            else -> { status.text="${doc.activeTool} 已選取；此官方 Slice 尚未實作此幾何，不產生假圖形"; first=null; return true }
        }
        first=null; status.text="已建立 ${doc.activeTool} • entities=${doc.entities.size}"; invalidate(); return true
    }
    override fun onDraw(c:Canvas){
        super.onDraw(c)
        doc.entities.forEach { e -> when(e){
            is CadLine -> c.drawLine((e.a.x*scale).toFloat(),(e.a.y*scale).toFloat(),(e.b.x*scale).toFloat(),(e.b.y*scale).toFloat(),paint)
            is CadRect -> c.drawRect((e.a.x*scale).toFloat(),(e.a.y*scale).toFloat(),(e.b.x*scale).toFloat(),(e.b.y*scale).toFloat(),paint)
            is CadCircle -> c.drawCircle((e.center.x*scale).toFloat(),(e.center.y*scale).toFloat(),(e.radius*scale).toFloat(),paint)
        } }
    }
}

object CadFeatureView {
    fun create(context:Context):LinearLayout {
        val doc=CadDocument(); val root=UiKit.column(context); val status=UiKit.label(context,"CAD READY • X0.000 Y0.000",14f)
        val row=LinearLayout(context).apply { orientation=LinearLayout.HORIZONTAL }
        val sc=HorizontalScrollView(context).apply { addView(row) }
        listOf(CadTool.LINE,CadTool.RECT,CadTool.CIRCLE,CadTool.HOLE,CadTool.ARC,CadTool.CHAMFER,CadTool.FILLET,CadTool.TRIM,CadTool.EXTEND,CadTool.OFFSET,CadTool.ARRAY).forEach { tool ->
            UiKit.addButton(row,tool.name){ doc.activeTool=tool; status.text="CAD TOOL = ${tool.name}" }
        }
        root.addView(sc); root.addView(status)
        root.addView(CadCanvasView(context,doc,status), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f))
        return root
    }
}
