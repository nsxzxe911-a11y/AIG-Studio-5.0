package com.aig.core.cad

import kotlin.math.round

enum class CadTool { SELECT, LINE, RECT, CIRCLE, ARC, HOLE, CHAMFER, FILLET, TRIM, EXTEND, OFFSET, ARRAY }
enum class SnapMode { END, MID, CENTER, INTERSECTION, HORIZONTAL, VERTICAL, TANGENT }
data class PointMm(val x:Double,val y:Double)
sealed interface CadEntity
data class CadLine(val a:PointMm,val b:PointMm):CadEntity
data class CadRect(val a:PointMm,val b:PointMm):CadEntity
data class CadCircle(val center:PointMm,val radius:Double):CadEntity

object CadPrecision {
    const val MM=0.001
    fun q(v:Double)=round(v/MM)*MM
}

class CadDocument {
    var activeTool:CadTool=CadTool.SELECT
    val entities=mutableListOf<CadEntity>()
    val snaps=SnapMode.entries.toMutableSet()
    fun add(entity:CadEntity){ entities += entity }
}
