package com.aig.fifth432

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.aig.core.ui.UiKit
import com.aig.feature.home.HomeFeatureView
import com.aig.feature.cad.CadFeatureView
import com.aig.feature.cam.CamFeatureView
import com.aig.feature.nc.NcFeatureView
import com.aig.renderer.unity.api.RendererContract

class MainActivity:Activity(){
    private lateinit var content:FrameLayout
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.statusBarColor=Color.rgb(2,4,7); window.navigationBarColor=Color.rgb(2,4,7)
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(2,4,7)) }
        val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val scroll=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false; addView(tabs) }
        val names=listOf("HOME","CAD","CAM","SIM","3AX","4AX","5AX","6AX","NC","AI")
        names.forEach { name -> UiKit.addButton(tabs,name){ open(name) } }
        content=FrameLayout(this)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f))
        setContentView(root); open("HOME")
    }
    private fun open(name:String){
        val view:View=when(name){
            "HOME"->HomeFeatureView.create(this)
            "CAD"->CadFeatureView.create(this)
            "CAM"->CamFeatureView.create(this)
            "NC"->NcFeatureView.create(this)
            "SIM","3AX","4AX","5AX","6AX"->rendererRequired(name)
            "AI"->message("AI 模組尚未連線；離線 Runtime 不被阻塞。")
            else->message("UNKNOWN")
        }
        content.removeAllViews(); content.addView(view)
    }
    private fun rendererRequired(name:String)=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setBackgroundColor(Color.rgb(2,4,7))
        addView(UiKit.label(this@MainActivity,"$name • 真 3D Renderer 尚未掛載",20f))
        addView(UiKit.label(this@MainActivity,RendererContract.POLICY,12f))
        addView(UiKit.label(this@MainActivity,"此頁故意不畫假機台。下一步由 Unity 官方 Export as Library 掛入 renderer-unity。",13f))
    }
    private fun message(s:String)=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setBackgroundColor(Color.rgb(2,4,7)); addView(UiKit.label(this@MainActivity,s,16f)) }
}
