package com.aig.feature.nc

import android.content.Context
import android.graphics.Color
import android.widget.EditText
import android.widget.LinearLayout
import com.aig.core.fanuc.*
import com.aig.core.ui.UiKit

object NcFeatureView {
    fun create(context:Context):LinearLayout {
        val root=UiKit.column(context); val editor=EditText(context).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(2,4,7)); textSize=13f; setHorizontallyScrolling(true) }
        val profile=FanucMachineProfile()
        val row=LinearLayout(context).apply { orientation=LinearLayout.HORIZONTAL }
        UiKit.addButton(row,"G34 + G83"){ editor.setText(FanucPost.boltCircleG83(BoltCircleCycle())) }
        UiKit.addButton(row,"M42 鎖軸"){ editor.append("\n${profile.lockAxisMCode}") }
        UiKit.addButton(row,"M44 解鎖"){ editor.append("\n${profile.unlockAxisMCode}") }
        UiKit.addButton(row,"自訂 M200"){ profile.setCustom("M200","USER CUSTOM"); editor.append("\nM200 (USER CUSTOM)") }
        root.addView(UiKit.label(context,"NC / Fanuc • 可直接編輯",17f)); root.addView(row); root.addView(editor,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f));
        editor.setText(FanucPost.boltCircleG83(BoltCircleCycle())); return root
    }
}
