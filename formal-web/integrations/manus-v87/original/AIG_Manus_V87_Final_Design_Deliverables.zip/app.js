const refs = {
  cad: 'https://aig-dual-formal-runtime.onrender.com/visual-library/authorities/20261019/cad_user_reference.jpg',
  six: 'https://aig-dual-formal-runtime.onrender.com/visual-library/authorities/20261019/6ax_user_reference.jpg'
};

const pages = {
  home: { code: 'H0', label: 'HOME', title: '從圖紙到數位成品', subtitle: '把每一個工作階段放回應有位置：主畫布先行，證據先行，真機權限永遠在主線安全 Gate 之後。', eyebrow: 'WORKSPACE / HOME' },
  cad: { code: 'C1', label: 'CAD', title: 'CAD 幾何設計', subtitle: '幾何、游標與 SNAP 只在本機草稿中互動；這裡不宣稱任何尺寸已被製造驗證。', eyebrow: 'DESIGN / CAD' },
  cam: { code: 'C2', label: 'CAM', title: 'CAM 刀路規劃', subtitle: '讓策略、刀具與退避條件集中在一個工作頁；計算結果只會成為待審核草稿。', eyebrow: 'PLAN / CAM' },
  sim: { code: 'S0', label: 'SIM', title: 'SIM 模擬檢查', subtitle: '真材料移除、碰撞、解析區塊與進度均保持未驗證狀態；前端不把模擬畫面當成機台回授。', eyebrow: 'EVIDENCE / SIM' },
  '3ax': { code: 'A3', label: '3AX', title: '3AX 三軸工作頁', subtitle: 'MACHINE 與 NC-first 共用同一個主畫布位置，右側坐標與底部狀態固定，方便鍵盤與游標操作。', eyebrow: 'MACHINE / 3AX', axis: '3AX', axes: ['X','Y','Z'], desc: '三軸立式銑削 · XYZ VMC' },
  '4ax': { code: 'A4', label: '4AX', title: '4AX 四軸工作頁', subtitle: '以 A 軸臥式旋轉為視覺骨架；旋轉角度與實際解析狀態不在原型中捏造。', eyebrow: 'MACHINE / 4AX', axis: '4AX', axes: ['X','Y','Z','A'], desc: '四軸臥式旋轉 · A 軸分度' },
  '5ax': { code: 'A5', label: '5AX', title: '5AX 五軸工作頁', subtitle: '把 A/B 搖籃姿態與遮擋提示放到主畫布旁，保留 NC-first 的手動接管路徑。', eyebrow: 'MACHINE / 5AX', axis: '5AX', axes: ['X','Y','Z','A','B'], desc: '五軸搖籃加工 · A/B 姿態' },
  '6ax': { code: 'A6', label: '6AX', title: '6AX 六軸工作頁', subtitle: '中央大型 CNC 視窗作為唯一視覺主角：直立 Z 主軸、獨臂搖籃與 A/B/C 旋轉僅作前端模型參考。', eyebrow: 'MACHINE / 6AX', axis: '6AX', axes: ['X','Y','Z','A','B','C'], desc: '六軸獨臂搖籃 · XYZABC' },
  nc: { code: 'N0', label: 'NC', title: 'NC Fanuc 草稿', subtitle: '編輯、解析、驗證與儲存都只作用於瀏覽器草稿；沒有上機輸出按鈕，也不代表 NC 安全。', eyebrow: 'PROGRAM / NC' },
  ai: { code: 'I0', label: 'AI', title: 'AI 協作預檢', subtitle: 'AI 只產生可追溯的工作計畫與缺口清單；沒有雲端帳號、也不把流程結果標成已完成。', eyebrow: 'COLLABORATION / AI' },
  toolpath: { code: 'TP', label: '3D TOOLPATH', title: '3D 走刀工作頁', subtitle: '獨立檢視刀路節點、加工順序與安全間隙；主畫布不被旁邊的工程控制面板奪走。', eyebrow: 'PATH / 3D TOOLPATH' }
};

const navItems = ['home','cad','cam','sim','3ax','4ax','5ax','6ax','nc','ai','toolpath'];
const state = { route: getRoute(), cadTool: 'SELECT', cadEntities: 0, snap: true, camStatus: '尚未計算', simReview: false, axisMode: new URLSearchParams(location.search).get('mode') === 'NC-FIRST' ? 'NC-FIRST' : 'MACHINE', ncOpen: false, ncDirty: false, ncStatus: '草稿未解析', aiPlan: false, aiAudit: false, selectedOperation: 0, selectedNode: 0 };
const defaultNC = `O6000\n( FRONTEND DRAFT / REVIEW ONLY )\nG90 G54 G17 G40 G49 G80\nN10 T01 M06\nN20 S12000 M03\nN30 G00 X0. Y0. Z50.\nN40 ( TOOLPATH SAMPLE - NOT VERIFIED )\nN50 G01 Z-2. F800\nN60 X60. Y0. F1200\nN70 X60. Y60.\nN80 X0. Y60.\nN90 X0. Y0.\nN99 M30`;

function getRoute() {
  const hash = location.hash.replace(/^#\/?/, '');
  if (hash && pages[hash]) return hash;
  const pathname = location.pathname.replace(/^\//, '').replace(/\/$/, '');
  return pages[pathname] ? pathname : 'home';
}

function getAxisMode() {
  return new URLSearchParams(location.search).get('mode') === 'NC-FIRST' ? 'NC-FIRST' : 'MACHINE';
}

function navigate(route) {
  if (!pages[route]) route = 'home';
  history.pushState({}, '', route === 'home' ? '/' : `/${route}`);
  state.route = route;
  state.axisMode = getAxisMode();
  render();
  document.querySelector('#main-content')?.focus({ preventScroll: true });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;' }[ch]));
}
function chip(text, tone = '') { return `<span class="state-chip ${tone}">${text}</span>`; }
function pageHeader(page, actions = '') {
  return `<div class="page-header"><div><p class="eyebrow">${page.eyebrow}</p><h1 class="page-title">${page.title}</h1><p class="page-subtitle">${page.subtitle}</p></div><div class="header-actions">${actions}</div></div>`;
}
function banner(extra = '所有狀態均為前端草稿，不連接 CNC、不代表精度、碰撞或材料移除驗收。') {
  return `<div class="prototype-banner"><span><strong>PROTO / REVIEW ONLY</strong> · ${extra}</span><span class="mono">NO MACHINE OUTPUT</span></div>`;
}
function panel(title, kicker, body, cls = '') { return `<section class="glass-panel panel-pad ${cls}"><div class="panel-kicker">${kicker}</div><h2 class="panel-title">${title}</h2>${body}</section>`; }

function renderNav() {
  const root = document.querySelector('#primary-nav');
  root.innerHTML = navItems.map(key => {
    const p = pages[key];
    return `<button class="nav-item" data-route="${key}" aria-current="${state.route === key ? 'page' : 'false'}"><span class="nav-code">${p.code}</span><span class="nav-label">${p.label}</span></button>`;
  }).join('');
}

function render() {
  renderNav();
  const pageRoot = document.querySelector('#page-root');
  const page = pages[state.route];
  if (page.axis) state.axisMode = getAxisMode();
  let html = '';
  if (state.route === 'home') html = renderHome();
  else if (state.route === 'cad') html = renderCAD();
  else if (state.route === 'cam') html = renderCAM();
  else if (state.route === 'sim') html = renderSIM();
  else if (pages[state.route].axis) html = renderAxis(page);
  else if (state.route === 'nc') html = renderNC();
  else if (state.route === 'ai') html = renderAI();
  else if (state.route === 'toolpath') html = renderToolpath();
  pageRoot.innerHTML = `<div class="page-wrap">${html}</div>`;
  bindInteractions();
}

function renderHome() {
  return pageHeader(pages.home, `<button class="button active" data-route="cad">開啟 CAD 草稿</button><button class="button ghost" data-action="open-contract">看設計契約</button>`) + banner('本原型只提供可審核的工作流佈局與前端狀態，正式核心仍留在主線。') + `
    <section class="home-hero">
      <div class="glass-panel hero-panel">
        <div><div class="panel-kicker">ONE WORKSPACE · SIX GATES</div><h2 class="hero-title">先看<em>證據</em>，<br>再讓刀路前進。</h2><p class="hero-copy">從照片與圖紙進入 CAD，經過 CAM、3D 走刀與 SIM 檢查，再交給 NC Gate。這裡先把每個決策點排好位置，避免用「在線」或「完成」掩蓋尚未驗證的工作。</p></div>
        <div class="hero-actions"><button class="button active" data-route="toolpath">進入 3D 走刀</button><button class="button outline amber" data-action="show-boundary">查看隔離邊界</button></div>
      </div>
      <aside class="glass-panel audit-panel"><div class="panel-kicker">PUBLIC SITE AUDIT / 2026-10</div><h2 class="panel-title">既有入口批判摘要</h2><div class="audit-list"><div class="audit-row"><i></i><div><strong>長頁堆疊控制台</strong><span>同一軸頁重複出現多組工具列與狀態。</span></div><span class="audit-tag">REWORK</span></div><div class="audit-row"><i></i><div><strong>6AX 主畫布不足</strong><span>缺少 65%～75% 的大型真機視窗層級。</span></div><span class="audit-tag">PRIORITY</span></div><div class="audit-row"><i></i><div><strong>原圖與功能需分離</strong><span>圖片庫應作參考卡，不能承接互動語意。</span></div><span class="audit-tag">KEEP</span></div></div>${chip('只稽核公開頁面 · 未控制正式站', 'amber')}</aside>
    </section>
    <div class="stat-strip"><div class="stat-cell"><span class="stat-value">11</span><span class="stat-label">工作頁／含 3D 走刀</span></div><div class="stat-cell"><span class="stat-value">0</span><span class="stat-label">真機連線</span></div><div class="stat-cell"><span class="stat-value">100%</span><span class="stat-label">狀態可追溯草稿</span></div><div class="stat-cell"><span class="stat-value">44px+</span><span class="stat-label">最小觸控尺寸</span></div></div>
    <section class="glass-panel panel-pad"><div class="panel-kicker">WORKFLOW / EVIDENCE ORDER</div><h2 class="panel-title">一條不越權的加工路徑</h2><div class="pipeline"><button class="pipeline-step" data-route="cad"><span>01</span><strong>CAD</strong><small>幾何與游標</small></button><button class="pipeline-step" data-route="cam"><span>02</span><strong>CAM</strong><small>策略與刀具</small></button><button class="pipeline-step" data-route="toolpath"><span>03</span><strong>3D 走刀</strong><small>節點與順序</small></button><button class="pipeline-step" data-route="sim"><span>04</span><strong>SIM</strong><small>材料／碰撞證據</small></button><button class="pipeline-step" data-route="nc"><span>05</span><strong>NC</strong><small>Fanuc 草稿</small></button><button class="pipeline-step" data-route="ai"><span>06</span><strong>AI</strong><small>缺口與交接</small></button></div></section>
    <div class="ref-grid"><article class="glass-panel ref-card"><figure><img src="${refs.cad}" alt="AIG 公開圖庫 CAD 使用者原圖視覺參考"><figcaption><strong>CAD 視覺參考</strong><span>公開圖庫原圖 · 非互動畫布 · IMG.AIGII.CAD.USER.20261019</span></figcaption></figure></article><article class="glass-panel ref-card"><figure><img src="${refs.six}" alt="AIG 公開圖庫 6AX 使用者原圖視覺參考"><figcaption><strong>6AX 視覺參考</strong><span>公開圖庫原圖 · 非真機回授 · IMG.AIGII.6AX.USER.20261019</span></figcaption></figure></article></div>`;
}

function renderCAD() {
  const toolset = ['LINE','RECT','CIRCLE','ARC','HOLE','SELECT'];
  return pageHeader(pages.cad, `<button class="button" data-action="cad-fit">縮放全圖</button><button class="button amber" data-action="cad-clear">清除草稿</button>`) + banner('CAD 可建立示意幾何；不產生製造承諾。') + `<div class="page-tabs"><button class="button active">GEOMETRY</button><button class="button ghost" data-route="cam">下一站：CAM</button></div><div class="canvas-layout"><section class="glass-panel workspace-card"><div class="toolbar"><span class="toolbar-label">TOOL /</span>${toolset.map(t => `<button class="tool-button ${state.cadTool === t ? 'active' : ''}" data-cad-tool="${t}">${t}</button>`).join('')}</div><div class="canvas-surface grid-lines"><svg class="cad-svg" viewBox="0 0 1000 560" role="img" aria-label="CAD 前端示意畫布"><path class="cad-geometry" d="M270 382 L270 220 Q270 192 298 192 H702 Q730 192 730 220 V382 Q730 410 702 410 H298 Q270 410 270 382Z"/><circle class="cad-geometry violet" cx="380" cy="300" r="53"/><circle class="cad-geometry" cx="620" cy="300" r="53"/><path class="cad-geometry" d="M430 300 H570"/><path class="cad-geometry" d="M500 170 V430" opacity=".55"/><path class="cad-geometry" d="M220 300 H780" opacity=".42"/><text class="axis-label" x="785" y="295">X+</text><text class="axis-label" x="505" y="158">Y+</text><text class="axis-label" x="228" y="435">0,0 / DRAFT</text></svg><div class="canvas-caption"><span>SELECT X 0.000</span><span>Y 0.000</span><span>SNAP ${state.snap ? 'ON' : 'OFF'}</span></div></div></section><aside class="side-stack"><section class="glass-panel panel-pad"><div class="panel-kicker">INSPECTOR / CAD-01</div><h2 class="panel-title">幾何屬性</h2><div class="inspector-list"><div class="inspect-row"><span>選取</span><strong>${state.cadEntities ? `${state.cadEntities} 個草稿` : '無'}</strong></div><div class="inspect-row"><span>拓樸</span><strong>DISCONNECTED</strong></div><div class="inspect-row"><span>狀態</span><strong>${state.cadTool === 'SELECT' ? '等待游標' : `工具 ${state.cadTool}`}</strong></div></div><label class="toggle"><input type="checkbox" data-action="toggle-snap" ${state.snap ? 'checked' : ''}> SNAP / 端點・中點・圓心</label><div class="control-row"><button class="button compact" data-action="cad-undo">復原</button><button class="button compact" data-action="cad-redo">重做</button><button class="button compact" data-action="cad-connect">連接</button></div></section>${panel('改動建議','DESIGN REVIEW','把「選取後才能 Trim / Extend / Offset」作為明確的狀態提示，並在主線 callback 回傳 selection id。建議先以游標 focus ring 與 keyboard shortcut 驗收。')} </aside></div>`;
}

function renderCAM() {
  const strategies = ['平面','輪廓','口袋','鑽孔','Z 等高','自適應'];
  return pageHeader(pages.cam, `<button class="button active" data-action="cam-calculate">計算刀路草稿</button><button class="button ghost" data-route="toolpath">開啟 3D 走刀</button>`) + banner('計算只建立待審核刀路草稿，不會送入 SIM 或 NC 生產流程。') + `<div class="canvas-layout"><section class="glass-panel workspace-card"><div class="toolbar"><span class="toolbar-label">STRATEGY /</span>${strategies.map((s,i) => `<button class="tool-button ${i === 1 ? 'active' : ''}" data-cam-strategy="${s}">${s}</button>`).join('')}</div><div class="panel-pad"><div class="stat-strip"><div class="stat-cell"><span class="stat-value">CAD</span><span class="stat-label">來源：本機草稿</span></div><div class="stat-cell"><span class="stat-value">—</span><span class="stat-label">刀路數</span></div><div class="stat-cell"><span class="stat-value">—</span><span class="stat-label">Z 層數</span></div><div class="stat-cell"><span class="stat-value">—</span><span class="stat-label">估算長度</span></div></div><div class="empty-state"><div><strong>${state.camStatus}</strong><p>按「計算刀路草稿」後，只會產生可檢視的前端候選。實際刀軸、夾具、毛坯與后處理仍需主線核心提供證據。</p></div></div></div></section><aside class="side-stack"><section class="glass-panel panel-pad"><div class="panel-kicker">PARAMETERS / CAM-02</div><h2 class="panel-title">刀具與參數</h2><div class="field-grid"><div class="field"><label>刀具 Ø / mm</label><input value="10.0" aria-label="刀具直徑" /></div><div class="field"><label>Safe-Z / mm</label><input value="5.0" aria-label="Safe-Z" /></div><div class="field"><label>進給 / mm/min</label><input value="—" placeholder="未設定" /></div><div class="field"><label>轉速 / RPM</label><input value="—" placeholder="未設定" /></div></div><div class="control-row"><button class="button compact" data-action="cam-read-cad">重讀 CAD 草稿</button><button class="button compact" data-action="cam-apply">套用至刀路</button></div></section>${panel('手動 CAM','NC-FIRST COMPANION','允許不經 CAD 直接輸入 G0 / G1，但每段仍須由 NC-first 與安全 Gate 重新驗證。這裡只保留入口，不把手動數值誤讀為已安全。')}</aside></div>`;
}

function renderSIM() {
  const axisKeys = ['3ax','4ax','5ax','6ax'];
  return pageHeader(pages.sim, `<button class="button" data-action="sim-refresh">更新資料</button><button class="button ghost" data-route="ai">AI 預檢</button>`) + banner('SIM 只顯示可追溯證據。沒有真正解析資料時，不顯示材料移除百分比或碰撞 PASS。') + `<div class="sim-overview"><section class="glass-panel panel-pad"><div class="panel-kicker">SIM RUNTIME / LOCAL-FIRST</div><h2 class="panel-title">加工狀態總覽</h2><p class="panel-copy">這裡把「證據不存在」和「證據通過」分開。按鈕只會進入 review mode，不會自動批准 NC，也不會啟動實體機台。</p><div class="axis-card-grid">${axisKeys.map(key => { const p = pages[key]; return `<article class="axis-card"><header><h3>${p.axis}</h3>${chip('未就緒','amber')}</header><p>${p.desc}</p><div class="metric-empty"><div><span>解析區塊</span><strong>—</strong></div><div><span>材料移除</span><strong>未驗證</strong></div><div><span>碰撞與警示</span><strong>無資料</strong></div><div><span>加工進度</span><strong>—</strong></div></div><button class="button compact" data-route="${key}">進入 ${p.axis} 工作頁</button></article>`; }).join('')}</div></section><aside class="side-stack">${panel('安全 Gate','EVIDENCE GATE',`<div class="empty-state"><div><strong>${state.simReview ? 'REVIEW MODE' : '尚未預檢'}</strong><p>${state.simReview ? '前端已進入審核檢視；沒有真實材料或碰撞模型，不得標示 PASS。' : '等待可解析程式、毛坯、刀具與碰撞核心回傳證據。'}</p><button class="button" data-action="sim-review">${state.simReview ? '結束審核檢視' : '進入審核檢視'}</button></div></div>`)}${panel('缺口','OPEN GAPS','需要主線提供：真實解析器結果、材料體積定義、夾具邊界、碰撞事件 schema、每一軸的時間軸與可重放證據。')}</aside></div>`;
}

function renderMachineSvg(axis) {
  const is6 = axis === '6AX';
  const cradle = is6 ? `<path class="violet" d="M330 420 Q500 485 670 420"/><path class="violet" d="M330 420 L300 352 M670 420 L700 352"/><ellipse class="violet" cx="500" cy="408" rx="178" ry="64"/><path class="glow" d="M400 382 L500 350 L600 382 L500 414Z"/><path class="glow" d="M445 355 L445 320 M555 355 L555 320"/>` : `<path class="violet" d="M382 388 H618"/><ellipse class="violet" cx="500" cy="382" rx="120" ry="36"/>`;
  const axisExtra = axis === '4AX' ? `<ellipse class="violet" cx="500" cy="386" rx="145" ry="44"/>` : axis === '5AX' ? `<path class="violet" d="M360 394 Q500 480 640 394"/>` : '';
  return `<svg class="machine-svg" viewBox="0 0 1000 650" role="img" aria-label="${axis} 前端 CNC 機台視覺模型，僅供佈局審核"><defs><linearGradient id="machineGlow" x1="0" x2="1"><stop offset="0" stop-color="#6ee7ff" stop-opacity=".22"/><stop offset="1" stop-color="#b892ff" stop-opacity=".2"/></linearGradient><pattern id="floorGrid" width="34" height="34" patternUnits="userSpaceOnUse"><path d="M34 0H0V34" fill="none" stroke="#6ee7ff" stroke-opacity=".07"/></pattern></defs><rect x="64" y="42" width="872" height="540" rx="22" fill="url(#floorGrid)"/><path class="frame" d="M160 485 H840 L780 550 H220Z"/><path class="frame-alt" d="M214 145 H786 V455 H214Z"/><path class="glow" d="M214 145 H786 M214 145 V455 M786 145 V455"/><path class="frame" d="M280 86 H720 L786 145 H214Z"/><path class="frame-alt" d="M450 94 H550 V300 H450Z"/><path class="glow" d="M450 94 V300 M550 94 V300"/><path class="frame" d="M412 285 H588 L625 330 H375Z"/><path class="glow" d="M500 300 V364"/><path class="frame-alt" d="M345 360 H655 V444 H345Z"/><rect class="stock" x="405" y="356" width="190" height="48" rx="6"/><path class="glow" d="M370 444 H630"/>${cradle}${axisExtra}<text x="80" y="90" class="axis-label">${axis} / FRONTEND MACHINE MODEL</text><text x="80" y="620" class="axis-label">Z ↑ · A/B/C ${is6 ? 'CRADLE REFERENCE' : 'AXIS REFERENCE'} · NOT A MACHINE FEEDBACK</text></svg>`;
}

function renderAxis(page) {
  const axes = page.axes.map(axis => `<div class="coordinate"><span>${axis}</span><strong>—</strong></div>`).join('');
  const ncClass = state.ncOpen ? '' : 'collapsed';
  return pageHeader(page, `<button class="button ${state.axisMode === 'MACHINE' ? 'active' : ''}" data-axis-mode="MACHINE">MACHINE</button><button class="button ${state.axisMode === 'NC-FIRST' ? 'active' : ''}" data-axis-mode="NC-FIRST">NC-FIRST</button><button class="button ghost" data-action="toggle-axis-nc">${state.ncOpen ? '收合 NC' : '展開 NC'}</button>`) + banner('MACHINE 與 NC-first 皆為前端 review subpage；任何數值與碰撞結果在未取回真實核心證據前保持空值。') + `<div class="machine-layout"><section class="glass-panel machine-viewport">${renderMachineSvg(page.axis)}</section><aside class="hud-stack"><section class="glass-panel hud-panel"><div class="panel-kicker">LIVE HUD / ${page.axis}</div><h2 class="panel-title">坐標與狀態</h2><div class="coordinate-grid">${axes}</div><div class="inspector-list"><div class="inspect-row"><span>模擬狀態</span><strong>未初始化</strong></div><div class="inspect-row"><span>碰撞</span><strong>無資料</strong></div><div class="inspect-row"><span>材料移除</span><strong>未驗證</strong></div><div class="inspect-row"><span>機台回授</span><strong>未連接</strong></div></div></section><section class="glass-panel hud-panel"><div class="panel-kicker">CONTROLS / REVIEW</div><h2 class="panel-title">只讀審核控制</h2><div class="control-row"><button class="button" data-action="axis-review">${state.axisMode === 'MACHINE' ? '播放 review' : '解析 NC 草稿'}</button><button class="button compact" data-action="axis-step">單步</button><button class="button compact" data-action="axis-reset">重設</button></div><p class="panel-copy">控制只更新前端視覺狀態；不會產生真機輸出。</p></section></aside><div class="status-band"><div class="status-cell"><span>任務狀態</span><strong>待處理</strong></div><div class="status-cell"><span>目前區塊</span><strong>—</strong></div><div class="status-cell"><span>進度</span><strong>未驗證</strong></div><div class="status-cell"><span>碰撞</span><strong>無資料</strong></div><div class="status-cell"><span>輸出</span><strong>停用</strong></div></div></div><section class="glass-panel nc-panel ${ncClass}"><div class="nc-heading"><div><span class="axis-badge">${page.axis} / NC-FIRST SUBPAGE</span><h3>Fanuc 草稿編輯器</h3></div><button class="button compact" data-action="toggle-axis-nc">${state.ncOpen ? '收合' : '展開'}</button></div><div class="nc-body"><div class="field"><label for="axis-nc">可編輯草稿；未經主線 parser / safety gate 驗證</label><textarea id="axis-nc" data-nc-editor>${escapeHTML(defaultNC)}</textarea></div><div class="control-row"><button class="button" data-action="nc-parse">重新解析</button><button class="button" data-action="nc-save">儲存草稿</button><button class="button amber" data-action="nc-clear">清除草稿</button></div></div></section>`;
}

function renderNC() {
  return pageHeader(pages.nc, `<button class="button" data-action="nc-parse">重新解析</button><button class="button active" data-action="nc-save">儲存草稿</button>`) + banner('NC 編輯器是隔離草稿區；「驗證」只表示前端格式檢查完成，不代表可上機。') + `<div class="grid grid-2"><section class="glass-panel panel-pad"><div class="panel-kicker">EDITOR / FANUC DRAFT</div><h2 class="panel-title">O6000 · 可追溯草稿</h2><div class="field" style="margin-top:18px"><label for="main-nc">游標與鍵盤可操作；資料不會離開此原型</label><textarea id="main-nc" data-nc-editor>${escapeHTML(defaultNC)}</textarea></div><div class="control-row"><button class="button" data-action="nc-parse">${state.ncStatus}</button><button class="button compact" data-action="nc-insert">插入行</button><button class="button compact" data-action="nc-undo">復原</button><button class="button compact" data-action="nc-redo">重做</button><button class="button amber" data-action="nc-clear">清除暫存</button></div></section><aside class="side-stack">${panel('NC Gate','SAFETY CONTRACT',`<div class="empty-state"><div><strong>${state.ncDirty ? 'DRAFT CHANGED' : 'DRAFT UNCHANGED'}</strong><p>${state.ncStatus}。真實驗證需要主線 parser、Fanuc dialect、刀長補償、座標系、夾具與 SIM evidence。</p></div></div>`)}${panel('危險鍵分離','DANGER ZONE',`<p class="panel-copy">本原型不提供「送出機台」「自動執行」或「上機」按鈕；這些能力必須在主線以權限、人工確認與獨立硬體安全 Gate 設計。</p><button class="button danger" data-action="show-boundary">檢視不可用能力</button>`)}</aside></div>`;
}

function renderAI() {
  return pageHeader(pages.ai, `<button class="button active" data-action="ai-plan">建立流程草稿</button><button class="button ghost" data-action="ai-audit">安全預檢</button>`) + banner('AI 不讀取雲端帳號與生產資料；只對本機原型狀態產生工作清單。') + `<section class="ai-grid"><article class="glass-panel ai-card"><div class="panel-kicker">01 / PLAN</div><h2 class="panel-title">加工流程</h2><p class="panel-copy">${state.aiPlan ? '已建立待審核的流程草稿：CAD → CAM → 3D 走刀 → SIM → NC Gate。' : '尚未建立。按下按鈕後顯示可交接的流程草稿，不表示加工完成。'}</p><button class="button" data-action="ai-plan">${state.aiPlan ? '更新流程草稿' : '建立方案'}</button></article><article class="glass-panel ai-card"><div class="panel-kicker">02 / AUDIT</div><h2 class="panel-title">缺口與安全檢查</h2><p class="panel-copy">${state.aiAudit ? '已列出缺口：材料模型、碰撞 schema、Fanuc parser、主線 callback。' : '尚未檢查。這裡不會給出虛假的 Release PASS。'}</p><button class="button amber" data-action="ai-audit">${state.aiAudit ? '重跑安全預檢' : '安全預檢'}</button></article><article class="glass-panel ai-card"><div class="panel-kicker">03 / HANDOFF</div><h2 class="panel-title">交接摘要</h2><p class="panel-copy">頁面與按鈕數量可複製給主線工程；不傳送圖紙、G-code 或帳號資料。</p><button class="button ghost" data-action="open-contract">開啟設計契約</button></article></section><div class="grid grid-2" style="margin-top:16px"><section class="glass-panel panel-pad"><div class="panel-kicker">TASK STATE</div><h2 class="panel-title">目前任務狀態</h2><div class="inspector-list"><div class="inspect-row"><span>AI 流程草稿</span><strong>${state.aiPlan ? 'DRAFT READY' : 'WAITING'}</strong></div><div class="inspect-row"><span>安全預檢</span><strong>${state.aiAudit ? 'GAPS LISTED' : 'NOT RUN'}</strong></div><div class="inspect-row"><span>正式核准</span><strong>未提供</strong></div><div class="inspect-row"><span>機台輸出</span><strong>停用</strong></div></div></section>${panel('邊界','MODEL BOUNDARY','目前只有離線規則型工作流提示，不是雲端對話模型；不自動產生已驗證的材料移除或 NC 指令。')}</div>`;
}

function renderToolpath() {
  const ops = ['OP10 · ROUGH / 未計算','OP20 · CONTOUR / 待審核','OP30 · FINISH / 未啟用'];
  return pageHeader(pages.toolpath, `<button class="button active" data-action="toolpath-fit">Fit 走刀</button><button class="button ghost" data-route="sim">送往 SIM 審核</button>`) + banner('3D 走刀是獨立工作頁；節點與順序只屬前端草稿，不代表真實刀具接觸或材料移除。') + `<div class="toolpath-layout"><section class="glass-panel toolpath-viewport"><div class="path-note">TOOLPATH CANVAS / 2.5D DRAFT / NO STOCK MODEL</div><svg viewBox="0 0 1100 700" role="img" aria-label="3D 走刀節點前端示意"><defs><pattern id="tpgrid" width="44" height="44" patternUnits="userSpaceOnUse"><path d="M44 0H0V44" fill="none" stroke="#6ee7ff" stroke-opacity=".07"/></pattern></defs><rect width="1100" height="700" fill="url(#tpgrid)"/><g transform="translate(120 35) rotate(-10 420 300)"><path class="path-line" d="M100 220 C170 60 360 40 520 132 S790 220 830 360 S700 530 500 505 S230 550 120 402 S42 290 100 220Z"/><path class="path-line" d="M178 245 C230 140 350 120 470 170 S690 240 726 340 S620 450 480 438 S275 466 198 370 S140 278 178 245Z" opacity=".62"/><path class="path-line" d="M260 282 C310 220 390 215 458 245 S570 300 584 355 S520 396 455 383 S340 402 294 350 S236 308 260 282Z" opacity=".45"/>${[[100,220],[520,132],[830,360],[500,505],[120,402],[178,245],[726,340],[480,438],[260,282],[584,355]].map(([x,y],i)=>`<circle class="path-node ${state.selectedNode===i?'selected':''}" data-node="${i}" tabindex="0" role="button" aria-label="選取刀路節點 ${i+1}" cx="${x}" cy="${y}" r="6"/>`).join('')}</g><text x="72" y="650" fill="#7790a1" font-family="IBM Plex Mono,monospace" font-size="11">SELECT NODE / ${state.selectedNode === null ? 'NONE' : `NODE ${state.selectedNode+1}`} · FRONTEND ONLY</text></svg></section><aside class="side-stack"><section class="glass-panel panel-pad"><div class="panel-kicker">OPERATIONS / 3D-TP</div><h2 class="panel-title">刀路列表</h2><div class="operation-list">${ops.map((o,i)=>`<button type="button" class="operation ${state.selectedOperation===i?'selected':''}" data-operation="${i}"><span>${o}</span><small>${i===0?'OFF':'—'}</small></button>`).join('')}</div><div class="control-row"><button class="button compact" data-action="toolpath-recalc">重新計算</button><button class="button compact" data-action="toolpath-verify">驗證草稿</button></div></section><section class="glass-panel panel-pad"><div class="panel-kicker">PARAMETERS / REVIEW</div><h2 class="panel-title">刀路參數</h2><div class="inspector-list"><div class="inspect-row"><span>Safe-Z</span><strong>未設定</strong></div><div class="inspect-row"><span>工作座標</span><strong>G54 / 草稿</strong></div><div class="inspect-row"><span>旋轉模式</span><strong>未選</strong></div><div class="inspect-row"><span>最小安全間隙</span><strong>未計算</strong></div></div><label class="toggle"><input type="checkbox" data-action="toggle-visibility" checked> 顯示節點</label></section></aside></div>`;
}

function bindInteractions() {
  document.querySelectorAll('[data-route]').forEach(el => el.addEventListener('click', () => navigate(el.dataset.route)));
  document.querySelectorAll('[data-cad-tool]').forEach(el => el.addEventListener('click', () => { state.cadTool = el.dataset.cadTool; if (state.cadTool !== 'SELECT') state.cadEntities += 1; toast(`CAD 工具 ${state.cadTool} 已選取；目前為草稿狀態。`); render(); }));
  document.querySelectorAll('[data-cam-strategy]').forEach(el => el.addEventListener('click', () => { document.querySelectorAll('[data-cam-strategy]').forEach(b => b.classList.remove('active')); el.classList.add('active'); toast(`策略 ${el.dataset.camStrategy} 已選取，尚未計算。`); }));
  document.querySelectorAll('[data-axis-mode]').forEach(el => el.addEventListener('click', () => { state.axisMode = el.dataset.axisMode; history.replaceState({}, '', `/${state.route}?mode=${encodeURIComponent(state.axisMode)}`); toast(`已切換 ${state.axisMode} subpage；仍不連接真機。`); render(); }));
  document.querySelectorAll('[data-operation]').forEach(el => el.addEventListener('click', () => { state.selectedOperation = Number(el.dataset.operation); render(); }));
  document.querySelectorAll('[data-node]').forEach(el => { el.addEventListener('click', () => { state.selectedNode = Number(el.dataset.node); toast(`已選取刀路節點 ${state.selectedNode + 1}；未改動任何真實刀路。`); render(); }); el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); } }); });
  document.querySelectorAll('[data-nc-editor]').forEach(el => el.addEventListener('input', () => { state.ncDirty = true; state.ncStatus = '草稿已變更'; }));
  document.querySelectorAll('[data-action]').forEach(el => el.addEventListener('click', () => handleAction(el.dataset.action)));
  document.querySelectorAll('input[data-action="toggle-snap"]').forEach(el => el.addEventListener('change', () => { state.snap = el.checked; render(); }));
}

function handleAction(action) {
  const actions = {
    'open-contract': () => openContract(),
    'show-boundary': () => openBoundary(),
    'cad-fit': () => toast('CAD 畫布已套用 Fit 視圖；不改變幾何。'),
    'cad-clear': () => { state.cadEntities = 0; state.cadTool = 'SELECT'; toast('已清除本頁前端草稿；沒有刪除主線資料。'); render(); },
    'cad-undo': () => toast('CAD 復原佇列目前只有前端示意，等待主線 callback 接入。', 'amber'),
    'cad-redo': () => toast('CAD 重做佇列目前只有前端示意，等待主線 callback 接入。', 'amber'),
    'cad-connect': () => toast('已提出 CONNECT callback 需求；拓樸仍為 DISCONNECTED。', 'amber'),
    'cam-calculate': () => { state.camStatus = 'DRAFT PATH GENERATED'; toast('已建立待審核的 CAM 草稿；尚未送往 SIM。'); render(); },
    'cam-read-cad': () => toast('已讀取本機 CAD 草稿入口；沒有真實幾何資料可解析。', 'amber'),
    'cam-apply': () => { state.camStatus = 'READY TO HANDOFF'; toast('刀路草稿已標記可交接；尚未通過安全 Gate。'); render(); },
    'sim-refresh': () => toast('SIM 資料重新掃描完成：仍沒有可解析的真實核心證據。', 'amber'),
    'sim-review': () => { state.simReview = !state.simReview; toast(state.simReview ? '已進入 review mode；不顯示假材料移除數值。' : '已離開 review mode。'); render(); },
    'toggle-axis-nc': () => { state.ncOpen = !state.ncOpen; render(); },
    'axis-review': () => toast('已切換前端 review 播放狀態；不代表 NC 執行。'),
    'axis-step': () => toast('單步請求已記錄為 UI intent；等待主線 parser callback。', 'amber'),
    'axis-reset': () => toast('前端視角已重設；未修改任何機台狀態。'),
    'nc-parse': () => { state.ncStatus = 'FORMAT REVIEW ONLY'; toast('格式檢查草稿完成；不代表 Fanuc 或機台安全。', 'amber'); render(); },
    'nc-save': () => { state.ncDirty = false; state.ncStatus = 'DRAFT SAVED LOCALLY'; toast('草稿已在本機原型狀態保存；未上傳、未送機。'); render(); },
    'nc-clear': () => { state.ncDirty = true; state.ncStatus = 'CLEAR PENDING REVIEW'; toast('清除暫存僅作用於本頁草稿；請勿視為清除正式資料。', 'amber'); render(); },
    'nc-insert': () => toast('游標插入行 intent 已觸發；主線需提供 editor callback。'),
    'nc-undo': () => toast('NC 復原 intent 已觸發；目前不修改正式內容。'),
    'nc-redo': () => toast('NC 重做 intent 已觸發；目前不修改正式內容。'),
    'ai-plan': () => { state.aiPlan = true; toast('已建立流程草稿：可交接，不代表加工完成。'); render(); },
    'ai-audit': () => { state.aiAudit = true; toast('已列出安全缺口；沒有 Release PASS。', 'amber'); render(); },
    'toolpath-fit': () => toast('3D 走刀已套用 Fit 視圖；節點仍為草稿。'),
    'toolpath-recalc': () => toast('重新計算需要主線 toolpath engine；此原型不捏造刀路數據。', 'amber'),
    'toolpath-verify': () => toast('草稿驗證入口已觸發；碰撞與材料移除仍為未驗證。', 'amber'),
    'toggle-visibility': () => toast('節點可見性已切換；未改動刀路資料。')
  };
  if (actions[action]) actions[action]();
}

function toast(message, tone = '') {
  const region = document.querySelector('#toast-region');
  const el = document.createElement('div'); el.className = `toast ${tone}`; el.textContent = message; region.appendChild(el);
  window.setTimeout(() => el.remove(), 4200);
}

function openBoundary() {
  document.querySelector('#modal-root').innerHTML = `<div class="modal-backdrop" data-close-modal><section class="modal" role="dialog" aria-modal="true" aria-labelledby="boundary-title"><div class="modal-head"><div><h2 id="boundary-title">隔離邊界 / Boundary</h2><p class="modal-intro">這個候選介面只在瀏覽器裡改變狀態。它不控制原站、不部署 Render、不讀取帳密與 NC 生產資料，也沒有任何真機輸出通道。</p></div><button class="button compact" data-action="close-modal">關閉</button></div><div class="risk-matrix"><div class="risk-row"><strong>允許</strong><span>頁面導覽、草稿狀態、CAD 示意工具、NC textarea、3D 節點選取、設計契約閱讀。</span><span class="state-chip cyan">LOCAL UI</span></div><div class="risk-row"><strong>刻意不做</strong><span>真機連線、MACHINE ONLINE、材料移除%、碰撞 PASS、0.001 mm 驗證、送出或自動執行。</span><span class="state-chip amber">BLOCKED</span></div><div class="risk-row"><strong>主線接手</strong><span>保留既有 DOM / HTML attribute / core callback，依契約逐頁接回並重新做安全驗收。</span><span class="state-chip violet">HANDOFF</span></div></div></section></div>`;
  bindModal();
}

function openContract() {
  const contractSpecs = {
    home: { sub: 'PRIMARY', areas: 'Header / Audit / Pipeline / Ref cards', buttons: 'H0-OPEN-CAD · H0-OPEN-TP · H0-CONTRACT', command: 'nav.openWorkspace(route)', callback: '(route, source) => Promise<WorkspaceIntent>', task: 'REVIEW SHELL · NO OUTPUT' },
    cad: { sub: 'GEOMETRY', areas: 'Tool rail / SVG canvas / Inspector', buttons: 'C1-LINE · C1-RECT · C1-SNAP · C1-CLEAR', command: 'cad.selectTool(toolId)', callback: '(toolId, cursor, snap) => { entityDraft, selection }', task: 'DRAFT GEOMETRY · DISCONNECTED' },
    cam: { sub: 'STRATEGY / PARAMETERS', areas: 'Strategy rail / Param panel / Handoff CTA', buttons: 'C2-STRATEGY · C2-CALCULATE · C2-APPLY', command: 'cam.requestDraftPath(action)', callback: '(strategy, tool, params) => Promise<PathDraft>', task: 'PATH DRAFT · NOT APPLIED' },
    sim: { sub: 'EVIDENCE GATE', areas: 'Axis cards / Runtime summary / Gap panel', buttons: 'S0-REFRESH · S0-REVIEW · S0-AXIS', command: 'sim.refreshEvidence()', callback: '(programId, stock, fixture) => Promise<SimEvidence>', task: 'WAITING EVIDENCE · NO PASS' },
    '3ax': { sub: 'MACHINE / NC-FIRST', areas: 'Machine viewport / XYZ HUD / Status band / NC drawer', buttons: 'A3-MACHINE · A3-NC-FIRST · A3-PLAY · A3-STEP', command: '3ax.reviewCommand(command, payload)', callback: '(mode, command, ncDraft) => Promise<ReviewState>', task: 'UNINITIALIZED · OUTPUT DISABLED' },
    '4ax': { sub: 'MACHINE / NC-FIRST', areas: 'Machine viewport / XYZA HUD / Status band / NC drawer', buttons: 'A4-MACHINE · A4-NC-FIRST · A4-PLAY · A4-STEP', command: '4ax.reviewCommand(command, payload)', callback: '(mode, command, axisState) => Promise<ReviewState>', task: 'UNINITIALIZED · OUTPUT DISABLED' },
    '5ax': { sub: 'MACHINE / NC-FIRST', areas: 'Cradle viewport / XYZAB HUD / Status band / NC drawer', buttons: 'A5-MACHINE · A5-NC-FIRST · A5-PLAY · A5-STEP', command: '5ax.reviewCommand(command, payload)', callback: '(mode, command, cradleState) => Promise<ReviewState>', task: 'UNINITIALIZED · OUTPUT DISABLED' },
    '6ax': { sub: 'MACHINE / NC-FIRST', areas: 'Large 65–75% viewport / XYZABC HUD / Status band / NC drawer', buttons: 'A6-MACHINE · A6-NC-FIRST · A6-PLAY · A6-STEP', command: '6ax.reviewCommand(command, payload)', callback: '(mode, command, cradleABC, ncDraft) => Promise<ReviewState>', task: 'UNINITIALIZED · NO MACHINE FEEDBACK' },
    nc: { sub: 'EDITOR / SAFETY GATE', areas: 'Fanuc textarea / Editor toolbar / Danger boundary', buttons: 'N0-PARSE · N0-SAVE · N0-INSERT · N0-CLEAR', command: 'nc.parseDraft() / nc.saveDraft()', callback: '(text, dialect, offsets) => Promise<ParseReview>', task: 'DRAFT CHANGED · FORMAT ONLY' },
    ai: { sub: 'PLAN / AUDIT / HANDOFF', areas: 'Plan card / Audit card / Handoff card', buttons: 'I0-PLAN · I0-AUDIT · I0-CONTRACT', command: 'ai.requestPlan(kind)', callback: '(localSnapshot, kind) => Promise<PlanDraft>', task: 'DRAFT PLAN · GAPS LISTED' },
    toolpath: { sub: 'PATH-CANVAS', areas: 'Large canvas / Operation list / Parameters', buttons: 'TP-FIT · TP-NODE · TP-RECALC · TP-VERIFY', command: 'toolpath.selectNode(nodeId)', callback: '(nodeId, operationId) => { selection, viewportIntent }', task: 'NODE DRAFT · NO STOCK MODEL' }
  };
  const rows = Object.keys(pages).map(key => { const p = pages[key]; const spec = contractSpecs[key]; return `<tr><td>${p.code} / ${p.label}</td><td>${spec.sub}<br><span class="mono">${spec.areas}</span></td><td><span class="mono">${spec.buttons}</span></td><td><span class="mono">${spec.command}</span><br><span class="mono">${spec.callback}</span></td><td>${spec.task}</td></tr>`; }).join('');
  document.querySelector('#modal-root').innerHTML = `<div class="modal-backdrop" data-close-modal><section class="modal" role="dialog" aria-modal="true" aria-labelledby="contract-title"><div class="modal-head"><div><h2 id="contract-title">Design Contract / 主線交接契約</h2><p class="modal-intro">每一頁可獨立驗收。Button ID 先採候選命名，正式整合時以既有 DOM 與 core callback 為準；本原型不要求把舊工程殼藏在新圖下。</p></div><button class="button compact" data-action="close-modal">關閉</button></div><div class="modal-section"><h3>Page / Subpage / Area / Button / Shared Command / Callback</h3><div class="glass-panel panel-pad"><table class="contract-table"><thead><tr><th>PAGE ID</th><th>SUBPAGE / 區域</th><th>BUTTON ID / 工具列</th><th>SHARED COMMAND / 實際 callback 介面</th><th>TASK STATE</th></tr></thead><tbody>${rows}</tbody></table></div></div><div class="modal-section"><h3>缺口 / 風險矩陣</h3><div class="risk-matrix"><div class="risk-row"><strong>R1 / HIGH</strong><span>真 CNC 核心尚未接入。主線需提供 machine feedback schema、權限、人工確認與 hard stop；原型只保留佈局。</span><span class="state-chip amber">BLOCK</span></div><div class="risk-row"><strong>R2 / HIGH</strong><span>材料移除與碰撞不可由 UI 推算。SIM 必須提供可重放 evidence、毛坯／刀具／夾具版本與事件時間軸。</span><span class="state-chip amber">BLOCK</span></div><div class="risk-row"><strong>R3 / MED</strong><span>Fanuc dialect、G54/G55、刀長補償與軸限需由 parser contract 定義；格式檢查不能升格為安全驗證。</span><span class="state-chip violet">OPEN</span></div><div class="risk-row"><strong>R4 / MED</strong><span>既有 HTML attribute、DOM 與 callback 必須原樣保留；整合時以 adapter 接回，不用新 UI 覆蓋舊核心。</span><span class="state-chip violet">OPEN</span></div></div></div><div class="modal-section"><h3>逐頁改動建議與具體驗收案例</h3><p class="panel-copy">HOME：可從導覽進入 CAD 且看見「隔離原型」；CAD：選取 RECT 後 counter 改變且 focus ring 可見；CAM：按計算後只出現 DRAFT PATH GENERATED；SIM：沒有真實 evidence 時永不出現材料移除百分比／碰撞 PASS；3AX～6AX：MACHINE / NC-first 可切換且坐標維持「—」；NC：修改 textarea 後顯示草稿變更而不提供送機；AI：建立方案後仍顯示待審核；3D 走刀：點節點只改變選取樣式，不宣稱切削完成；手機：導航可橫向滑動、按鈕不擠壓且每個 hit area ≥ 44px。</p></div></section></div>`;
  bindModal();
}

function bindModal() {
  document.querySelectorAll('[data-close-modal]').forEach(el => el.addEventListener('click', e => { if (e.target === el) closeModal(); }));
  document.querySelectorAll('[data-action="close-modal"]').forEach(el => el.addEventListener('click', closeModal));
  document.addEventListener('keydown', escHandler, { once: true });
}
function escHandler(e) { if (e.key === 'Escape') closeModal(); }
function closeModal() { document.querySelector('#modal-root').innerHTML = ''; }

window.addEventListener('popstate', () => { state.route = getRoute(); render(); });
window.addEventListener('hashchange', () => { state.route = getRoute(); render(); });
render();
