export default {
  logoUrl: "https://aig-dual-formal-runtime.onrender.com/visual-library/authorities/20261019/cad_user_reference.jpg"
};
