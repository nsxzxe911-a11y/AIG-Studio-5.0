import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 3000);
const mime = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8', '.xml':'application/xml; charset=utf-8', '.txt':'text/plain; charset=utf-8', '.ts':'text/plain; charset=utf-8' };
const routeFiles = new Set(['/','/cad','/cam','/sim','/3ax','/4ax','/5ax','/6ax','/nc','/ai','/toolpath']);

function safePath(urlPath) {
  const decoded = decodeURIComponent(urlPath.split('?')[0]);
  if (decoded.includes('..')) return null;
  return decoded;
}

const server = http.createServer(async (req, res) => {
  const urlPath = safePath(req.url || '/');
  if (!urlPath) { res.writeHead(400); res.end('Bad path'); return; }
  let filePath = path.join(root, urlPath === '/' ? 'index.html' : urlPath.replace(/^\//, ''));
  if (!existsSync(filePath) || (urlPath !== '/' && routeFiles.has(urlPath))) {
    if (urlPath.startsWith('/manus-routes.json') || urlPath.startsWith('/robots.txt') || urlPath.startsWith('/sitemap.xml')) {
      filePath = path.join(root, 'public', urlPath.replace(/^\//, ''));
    } else if (routeFiles.has(urlPath)) {
      filePath = path.join(root, 'index.html');
    }
  }
  try {
    const body = await readFile(filePath);
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': mime[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(body);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }
});
server.listen(port, '0.0.0.0', () => console.log(`AIG-II isolated prototype listening on ${port}`));
