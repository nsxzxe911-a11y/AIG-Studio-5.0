# AIG-II CNC Studio 5.0｜隔離 UI/UX 原型計畫

## 目標與邊界
本專案是獨立於 `aig-dual-formal-runtime.onrender.com` 的前端設計提案／隔離原型，用於由人類審核後擇優回主線。它不控制、不部署、不覆蓋正式 Render 網站，不索取帳密、API key 或 NC 生產資料，也不發出真機指令。

既有公開站稽核摘要：目前入口已明示「僅模擬、無機台輸出」與「舊圖庫原圖預覽」，但工作頁長度過長、工程控制台重複、6AX 大型真機加工視窗與可驗收狀態模型不足。因此本原型採「單一主工作畫布 + 固定工具列 + 可收合側欄」取代重複控制台，並將 MACHINE / NC-first 分成同一軸頁的明確 subpage。

## 實作方式
- 技術：純 HTML/CSS/JavaScript + Node 內建 HTTP server，無資料庫、無外部 API、無真機連線。
- 導覽：可用 clean path（`/cad`、`/6ax`、`/toolpath`）與瀏覽器返回，所有頁面由同一個可操作 UI shell 渲染。
- 互動：工具列按鈕、tab、toggle、modal、textarea、可鍵盤聚焦的視覺節點與響應式導覽均在前端有狀態變化；所有狀態文案明示「草稿／未驗證／不代表機台回授」。
- 視覺參考：使用 AIG 公開圖庫提供的 CAD 使用者原圖與 6AX 使用者原圖作為視覺對照卡，不把整張圖片當按鈕或畫布。
- 視窗：以 Windows 3840×2160 為主版比例，手機用獨立堆疊與觸控尺寸規則，不單純縮小桌面畫面。
- 原型資料：預設沒有真實幾何、刀路、材料移除、碰撞、精度或機台在線數據；示例 G-code 與視覺模型均標註為教學／佈局草稿。

## Design

### 備選風格
- 近黑工業儀表：0.07；容易落入傳統工程面板，保留為退路。
- **RGB Glassline / Precision Cinema：0.08（採用）**；用單一連續畫布與玻璃色邊界表現加工流程的深度，不用積木式方框堆滿畫面。
- 霧面白色工坊：0.05；與既有 RGB 視覺語言不連續。

### Design Movement
RGB Glassline / Precision Cinema：把 CNC 的刀軌、主軸與坐標軸視為一條可讀的光路，畫面層級像專業剪輯室而不是 ERP 儀表板。

### Core Principles
1. 主畫布優先：每頁只保留一個主工作焦點，輔助設定可收合。
2. 狀態不造假：任何加工結果都以「未驗證／資料缺口」呈現，不用綠色宣稱 PASS。
3. 位置可預期：頁面導覽、工具列、危險鍵與狀態列在十頁保持同一落點。
4. 可操作而不越權：按鈕能反映草稿狀態，但永遠不形成真機輸出能力。

### Color Philosophy
`#020407` 作為深色舞台，`#07111B` 作為承載工作內容的 panel；cyan 表達幾何與游標、blue 表達路徑與視角、violet 表達 AI 與跨頁協作。危險操作採琥珀而非紅色發光，避免把警告誤讀成完成綠燈。

### Layout Paradigm
左側固定工作導覽、中央寬幅主畫布、右側資料檢查；在 6AX 與 3D 走刀頁中央畫布占 65%～75%，下方統一為可讀狀態帶。手機改為頂端頁籤＋縱向畫布＋底部觸控工具列，避免桌面面板擠在窄欄。

### Signature Elements
- 繞角但不封閉的 cyan/violet glassline 邊界。
- `PROTO / REVIEW ONLY` 雙標籤，固定出現在 header 與主畫布。
- 坐標字串與狀態欄採等寬字，讓遊標與鍵盤操作有明確錨點。

### Interaction / Animation
按鈕使用 120ms 的邊框亮度與位移回饋；畫布節點可被選取但不模擬真切削。modal、側欄、NC 編輯器採可鍵盤聚焦與 Escape 關閉；禁止會導致誤觸的連續自動動畫。任何「開始」只會進入 review mode，不會改寫成完成或在線。

### Typography / Brand
標題採 `Space Grotesk`（若未載入則 `Arial`），中文採 `Noto Sans TC` 系統回退；資料與 NC 採 `IBM Plex Mono` / `Consolas`。品牌語氣：精準、克制、可追溯。示例文案：「先看證據，再讓刀路前進。」、「這是可交接的設計契約，不是機台授權。」

### Wordmark & Brand Color
Wordmark 以「AIG-II」與一條不閉合的三色光路構成，代表 CAD→CAM→SIM→NC 的連續但可中止流程。招牌色為 `#6EE7FF`，作為 cursor cyan，用來指向而不是裝飾。

## 專案結構
- `index.html`：可爬取的首頁骨架與根節點。
- `styles.css`：桌面 4K、手機觸控、畫布與 glassline 元件。
- `app.js`：頁面資料、路由、狀態機、互動、設計契約 modal。
- `server.js`：零依賴預覽 server，支援 clean path fallback。
- `public/manus-routes.json`：所有可預覽頁面清單。
- `TODO.md`：依使用者要求拆分的可驗收交付項目。

## 交付策略
本階段只啟動預覽，不做 GitHub main、Render 正式部署或任何外部站點覆蓋；若後續要採用，主線工程需另行依契約逐頁接回既有 DOM/core callback，並通過風險矩陣中的實機安全 Gate。
