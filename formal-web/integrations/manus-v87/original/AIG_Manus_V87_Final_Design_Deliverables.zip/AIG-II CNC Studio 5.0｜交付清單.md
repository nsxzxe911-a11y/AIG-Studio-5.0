# AIG-II CNC Studio 5.0｜交付清單

- [x] **隔離與安全邊界**
  - 成果是獨立可預覽的前端原型，不發布或覆蓋 `aig-dual-formal-runtime.onrender.com`。
  - 未索取帳密、API key、NC 生產資料；未發真機指令、不自動動 CNC machine。
  - 所有 MACHINE ONLINE、材料移除%、碰撞 PASS、0.001 mm 已驗證等欄位均以未驗證、無資料或停用呈現。

- [x] **十頁與獨立工作頁**
  - 已包含 HOME / CAD / CAM / SIM / 3AX / 4AX / 5AX / 6AX / NC / AI 十頁，以及獨立 `/toolpath` 3D 走刀工作頁。
  - 3AX/4AX/5AX/6AX 各有 MACHINE 與 NC-first subpage；可由同頁 tab 切換，也會同步 `?mode=NC-FIRST` 以便獨立定位；軸頁主畫布、右側 XYZABC、底部加工狀態位置一致。
  - 6AX 桌面主加工視窗採約 65%～75% 內容比例，呈現直立 Z 主軸與 A/B/C 搖籃視覺語彙；不以積木機構或假數據冒充真 CNC 核心。

- [x] **互動與可操作性**
  - 工具列、tab、toggle、modal、NC 草稿編輯、CAD 工具與 3D 走刀節點有明確狀態變化。
  - 原生按鈕位置規律、一致、可用游標與鍵盤操作；focus-visible 清楚，危險鍵與一般動作分離；3D 節點具 `tabindex`、Enter/Space 選取行為。
  - 手機使用獨立堆疊與至少 44px 觸控尺寸，按鈕不互相擠壓；導覽可橫向滑動。
  - 不把整張圖片做假按鈕；CAD 與 6AX 圖片只作視覺參考卡。

- [x] **設計契約**
  - DESIGN CONTRACT modal 已公開每頁 Page ID、Subpage/區域、Button ID、Shared Command、實際 callback 介面、任務狀態與缺口/風險矩陣。
  - 逐頁改動建議與具體驗收案例可由 modal 閱讀，不依賴私有文件。
  - 已明示既有 HTML 屬性、DOM 及核心不得被本原型要求隱藏；成果僅是候選介面。

- [x] **預覽與技術**
  - `GET /manus-routes.json` 回傳 11 個完整 route 宣告。
  - `PORT=3000 node server.js` 可啟動，預覽可直接進入 `/`、`/cad`、`/6ax`、`/toolpath` 與其餘 clean paths。
  - 只使用前端本地狀態，無 server/database capability；node 語法檢查與 route HTTP smoke test 已通過。

- [ ] **主線工程接手與真實安全驗收（刻意保留）**
  - 尚未接入真 CNC 核心、材料模型、碰撞 evidence、Fanuc parser、權限／人工確認／hard stop；這些不屬隔離原型可自行補造的內容。
  - 正式整合時必須保留既有 HTML attribute、DOM 與核心 callback，以 adapter 逐頁接回，不把本原型視為 GitHub main 或 Render 正式部署。
